<?php
echo $_POST["name"];
// if($_POST["submit"]) {
// 	echo "ok"
//     // mail("sdhull@gmail.com", "Form to email message", $_POST["message"], "From: an@email.address");
// }
?>